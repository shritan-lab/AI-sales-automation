require('dotenv').config();
const express = require('express');
const cors = require('cors');
const path = require('path');
const { Anthropic } = require('@anthropic-ai/sdk');
const nodemailer = require('nodemailer');

const app = express();
app.use(cors());
app.use(express.json());
app.use(express.static(path.join(__dirname, 'public')));

const anthropic = new Anthropic({ apiKey: process.env.ANTHROPIC_API_KEY });

const VIBE_MCP = {
  type: 'url',
  url: 'https://vibeprospecting.explorium.ai/mcp',
  name: 'vibe-prospecting',
};

const GMAIL_MCP = {
  type: 'url',
  url: 'https://gmail.mcp.claude.com/mcp',
  name: 'gmail-mcp',
};

// ─── Helper: extract all text blocks from a response ─────────────────────────
function getText(response) {
  if (!response?.content) return '';
  return response.content
    .filter((b) => b.type === 'text')
    .map((b) => b.text)
    .join('\n');
}

// ─── Helper: extract tool results from a response ────────────────────────────
function getToolResults(response) {
  if (!response?.content) return [];
  return response.content
    .filter((b) => b.type === 'mcp_tool_result')
    .map((b) => {
      const raw = b.content?.[0]?.text || b.content || '';
      try {
        return typeof raw === 'string' ? JSON.parse(raw) : raw;
      } catch {
        return raw;
      }
    });
}

// ─── Helper: parse JSON from possibly messy text ──────────────────────────────
function parseJSON(text) {
  // Try direct parse
  try { return JSON.parse(text); } catch {}
  // Try extracting array
  const arrMatch = text.match(/\[[\s\S]*\]/);
  if (arrMatch) { try { return JSON.parse(arrMatch[0]); } catch {} }
  // Try extracting object
  const objMatch = text.match(/\{[\s\S]*\}/);
  if (objMatch) { try { return JSON.parse(objMatch[0]); } catch {} }
  return null;
}

// ─── ROUTE: Health check ──────────────────────────────────────────────────────
app.get('/api/health', (req, res) => {
  res.json({
    ok: true,
    anthropic: !!process.env.ANTHROPIC_API_KEY,
    gmail_user: process.env.GMAIL_USER || null,
    vibe_token: !!process.env.VIBE_PROSPECTING_TOKEN,
  });
});

// ─── ROUTE: Lead Search ───────────────────────────────────────────────────────
app.post('/api/leads', async (req, res) => {
  const { niche, level, size, country, count } = req.body;

  if (!process.env.ANTHROPIC_API_KEY) {
    return res.status(400).json({ error: 'ANTHROPIC_API_KEY not set in .env' });
  }

  try {
    const mcpServers = process.env.VIBE_PROSPECTING_TOKEN
      ? [{ ...VIBE_MCP, headers: { Authorization: `Bearer ${process.env.VIBE_PROSPECTING_TOKEN}` } }]
      : [VIBE_MCP];

    const prompt = `Use the Vibe Prospecting fetch-entities tool to find ${count} prospects.

Required filters:
- entity_type: "prospects"
- job_level: ["${level}"]
- company_size: ["${size}"]
- company_country_code: ["${country}"]
- has_email: true
- number_of_results: ${count}

After fetching, extract the prospect data and return ONLY a JSON array with this exact structure (no markdown, no explanation):
[
  {
    "name": "Full Name",
    "title": "Job Title", 
    "company": "Company Name",
    "email": "email@company.com",
    "website": "https://company.com",
    "linkedin": "linkedin url or empty string",
    "industry": "${niche}",
    "company_size": "${size}",
    "country": "${country}"
  }
]

Return ONLY the JSON array. Nothing else.`;

    const response = await anthropic.messages.create({
      model: 'claude-sonnet-4-20250514',
      max_tokens: 4096,
      messages: [{ role: 'user', content: prompt }],
      mcp_servers: mcpServers,
    });

    const text = getText(response);
    const toolResults = getToolResults(response);

    let leads = [];

    // Try tool results first
    for (const tr of toolResults) {
      if (Array.isArray(tr)) { leads = tr; break; }
      if (tr?.prospects && Array.isArray(tr.prospects)) { leads = tr.prospects; break; }
      if (tr?.data && Array.isArray(tr.data)) { leads = tr.data; break; }
      if (tr?.results && Array.isArray(tr.results)) { leads = tr.results; break; }
    }

    // Fall back to text parsing
    if (!leads.length && text) {
      const parsed = parseJSON(text);
      if (Array.isArray(parsed)) leads = parsed;
      else if (parsed?.prospects) leads = parsed.prospects;
      else if (parsed?.data) leads = parsed.data;
    }

    // Normalize field names
    leads = leads.slice(0, parseInt(count)).map((l, i) => ({
      id: i,
      name: l.name || l.full_name || [l.first_name, l.last_name].filter(Boolean).join(' ') || `Prospect ${i + 1}`,
      title: l.title || l.job_title || level,
      company: l.company || l.company_name || 'Unknown Company',
      email: l.email || l.work_email || l.personal_email || '',
      website: l.website || l.company_website || l.domain || '',
      linkedin: l.linkedin || l.linkedin_url || '',
      industry: niche,
      company_size: size,
      country,
      score: Math.min(100, Math.max(60, Math.floor(Math.random() * 35) + 65)),
    }));

    res.json({ leads, raw: text.slice(0, 500) });
  } catch (err) {
    console.error('Lead search error:', err.message);
    res.status(500).json({ error: err.message });
  }
});

// ─── ROUTE: Generate single personalized email ────────────────────────────────
app.post('/api/generate-email', async (req, res) => {
  const { lead, service, senderName } = req.body;

  if (!process.env.ANTHROPIC_API_KEY) {
    return res.status(400).json({ error: 'ANTHROPIC_API_KEY not set in .env' });
  }

  try {
    const prompt = `Write a high-converting cold email FROM ${senderName} TO ${lead.name} (${lead.title} at ${lead.company}).

Context:
- Their industry: ${lead.industry}
- Company size: ${lead.company_size} employees
- Website: ${lead.website || lead.company + '.com'}
- Service to offer: ${service}

Rules:
- Max 75 words in body
- Reference something SPECIFIC about their business or industry pain point
- One clear benefit tied to that pain point  
- Soft CTA: 15-minute call this week
- Tone: premium, confident, human, conversational
- NEVER use: "synergy", "leverage", "innovative", "cutting-edge", "I hope this finds you well"
- No opener like "My name is..." — start with the hook
- Sign off with just: ${senderName}

Return ONLY valid JSON (no markdown, no backticks):
{"subject":"subject line max 8 words","body":"full email body text"}`;

    const response = await anthropic.messages.create({
      model: 'claude-sonnet-4-20250514',
      max_tokens: 512,
      messages: [{ role: 'user', content: prompt }],
    });

    const text = getText(response);
    const parsed = parseJSON(text);

    if (parsed?.subject && parsed?.body) {
      res.json({ subject: parsed.subject, body: parsed.body });
    } else {
      // Fallback
      res.json({
        subject: `Quick question about ${lead.company}`,
        body: `${lead.name.split(' ')[0]},\n\nI checked out ${lead.company} — you're building something solid in the ${lead.industry} space.\n\nMost ${lead.industry} businesses at your stage are leaving leads on the table without ${service}. We help fix that, typically within 30 days.\n\nWorth a 15-minute call this week?\n\n${senderName}`,
      });
    }
  } catch (err) {
    console.error('Email gen error:', err.message);
    res.status(500).json({ error: err.message });
  }
});

// ─── ROUTE: Send email via Gmail SMTP ────────────────────────────────────────
app.post('/api/send-email', async (req, res) => {
  const { to, subject, body, fromName } = req.body;

  if (!process.env.GMAIL_USER || !process.env.GMAIL_APP_PASSWORD) {
    return res.status(400).json({
      error: 'GMAIL_USER and GMAIL_APP_PASSWORD not set in .env. See README.',
      setup_url: 'https://myaccount.google.com/apppasswords',
    });
  }

  if (!to || !to.includes('@')) {
    return res.status(400).json({ error: 'Invalid or missing email address' });
  }

  try {
    const transporter = nodemailer.createTransport({
      service: 'gmail',
      auth: {
        user: process.env.GMAIL_USER,
        pass: process.env.GMAIL_APP_PASSWORD,
      },
    });

    const info = await transporter.sendMail({
      from: `"${fromName || 'Sales'}" <${process.env.GMAIL_USER}>`,
      to,
      subject,
      text: body,
    });

    res.json({ success: true, messageId: info.messageId, to });
  } catch (err) {
    console.error('Gmail send error:', err.message);
    res.status(500).json({ error: err.message, to });
  }
});

// ─── ROUTE: Send via Gmail MCP (alternative — uses connected Claude account) ──
app.post('/api/send-email-mcp', async (req, res) => {
  const { to, subject, body, fromName } = req.body;

  if (!process.env.ANTHROPIC_API_KEY) {
    return res.status(400).json({ error: 'ANTHROPIC_API_KEY not set' });
  }

  try {
    const response = await anthropic.messages.create({
      model: 'claude-sonnet-4-20250514',
      max_tokens: 512,
      messages: [{
        role: 'user',
        content: `Send this email using the Gmail tool RIGHT NOW. Do not ask questions, just send it.

To: ${to}
Subject: ${subject}
Body:
${body}

After sending, respond with exactly: SENT:${to}`,
      }],
      mcp_servers: [GMAIL_MCP],
    });

    const text = getText(response);
    const success = text.includes('SENT:') || text.toLowerCase().includes('sent successfully') || text.toLowerCase().includes('email has been sent');

    res.json({ success, response: text.slice(0, 200), to });
  } catch (err) {
    console.error('MCP send error:', err.message);
    res.status(500).json({ error: err.message, to });
  }
});

// ─── ROUTE: Qualify reply with AI ────────────────────────────────────────────
app.post('/api/qualify-reply', async (req, res) => {
  const { reply, leadName, industry, service } = req.body;

  try {
    const response = await anthropic.messages.create({
      model: 'claude-sonnet-4-20250514',
      max_tokens: 256,
      messages: [{
        role: 'user',
        content: `Classify this reply to a cold email about ${service} for a ${industry} business.

Reply from ${leadName}:
"${reply}"

Respond ONLY with JSON:
{
  "category": "INTERESTED" | "NOT_NOW" | "NEEDS_INFO" | "NOT_INTERESTED",
  "confidence": 0.0-1.0,
  "key_signal": "one short phrase",
  "suggested_action": "what to do next"
}`,
      }],
    });

    const parsed = parseJSON(getText(response));
    res.json(parsed || { category: 'NEEDS_INFO', confidence: 0.5, key_signal: 'unclear', suggested_action: 'Follow up with more context' });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// ─── Catch-all: serve frontend ────────────────────────────────────────────────
app.get('*', (req, res) => {
  res.sendFile(path.join(__dirname, 'public', 'index.html'));
});

const PORT = process.env.PORT || 3000;
app.listen(PORT, () => {
  console.log(`\n🚀 AI Sales Automation running at http://localhost:${PORT}`);
  console.log(`   Anthropic API: ${process.env.ANTHROPIC_API_KEY ? '✓ configured' : '✗ missing (set ANTHROPIC_API_KEY in .env)'}`);
  console.log(`   Gmail SMTP:    ${process.env.GMAIL_USER ? `✓ ${process.env.GMAIL_USER}` : '✗ missing (set GMAIL_USER + GMAIL_APP_PASSWORD in .env)'}`);
  console.log(`   Vibe Token:    ${process.env.VIBE_PROSPECTING_TOKEN ? '✓ configured' : '⚠ optional (uses Claude session auth)'}`);
  console.log('');
});
